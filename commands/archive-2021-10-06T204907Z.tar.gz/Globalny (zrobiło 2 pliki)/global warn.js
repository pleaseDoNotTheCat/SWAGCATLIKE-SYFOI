module.exports =  {
    name: "gwarn",
    code: `Ostrzezono
$onlyForIDs[847042688675217439;850843293272113163;526711537373806592;246158728393523200;586148596936736768; :x: brak uprawnień moderator bota]`
}