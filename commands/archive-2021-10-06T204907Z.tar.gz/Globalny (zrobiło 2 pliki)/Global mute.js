module.exports = {
    name: "gmute",
    code: `
    $setGlobalUserVar[rank;$message[2];mute] wyciszono $onlyForIDs[850843293272113163;847042688675217439; brak permisji wlasciciel bota]