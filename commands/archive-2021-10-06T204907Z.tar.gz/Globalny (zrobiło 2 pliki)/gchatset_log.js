module.exports = {
    name: "set",
    aliases: ['gchat', 'globalchatset'],
    code: `$djseval[console.log('Cześć moderatorze, jakiś serwer chce weryfikacji sprawdź to.')]`
}