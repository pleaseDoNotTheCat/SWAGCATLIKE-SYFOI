module.exports = {
    name: "gmute",
    code: `
   $title[MUTE NA GLOBALU]
$description[Zostałeś wyciszony przez $username 
powod: $nomentionmessage]
$footer[$addtimestamp]
$color[RED]
$dm[$message[1]]
$onlyForIDs[850843293272113163;847042688675217439; brak permisji wlasciciel bota]`
}