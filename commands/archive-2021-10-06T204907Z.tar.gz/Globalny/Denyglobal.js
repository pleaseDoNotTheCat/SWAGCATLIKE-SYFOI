module.exports =  {
    name: "denyglobal",
    code: `$title[Tak więc]
$description[twoja prośba o ustawienie globala została odrzucona
możliwe powody: nie wlasciwa nazwa serwera, ukarana osoba, dzialanie na szkodę globala]
$footer[odrzucono $addTimestamp]
$color[RED]
$dm[$message[1]]
$onlyForIDs[847042688675217439;850843293272113163;526711537373806592;246158728393523200;586148596936736768; :x: brak uprawnień moderator bota]`
}