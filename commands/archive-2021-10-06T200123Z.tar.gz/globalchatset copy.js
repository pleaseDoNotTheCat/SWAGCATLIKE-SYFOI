module.exports = {
    name: "set",
    aliases: ['gchat', 'globalchatset'],
    code: `$setServerVar[gchat;$createWebhook[$channelID;GlobalChat;https://images-ext-2.discordapp.net/external/XaofodO7E-5yHLWpDnSke1ekM3Caf7Hj7GD5vaAMT8Y/https/i.ytimg.com/vi/gqmr01N0ydM/hqdefault.jpg;yes;#SEMI#]]
    $setServerVar[gchatch;$mentionedChannels[1]]
$onlyforids[850843293272113163;526711537373806592;246158728393523200;847042688675217439;586148596936736768; :x: brak uprawnienia moderator bota]`
}