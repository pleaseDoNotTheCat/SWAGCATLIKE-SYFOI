module.exports = {
    name: "global",
    
    code: `$channelsendmessage[893551250015141918; PROSBA O ZALOZENIE SYFU GLOBALNEGO

ID OSOBY $authorID
ZAPROSZENIE JAK NIE MA ZAPRA TO IGNORUJ: $message]
Oczekuj na zweryfikowanie
$argscheck[1; wyslij zaproszenie do serwera]`
}