const msg = "$message"
const optins = "$getServerVar[gchat]"

module.exports = [{
    name: "$alwaysExecute",
    code: `$forEachGuild[gchat]
    
    $onlyForChannels[$getServerVar[gchatch];]
$blacklistIDS[540984502252601356;861207072322093057;428128533064187905; ]
`
}, {
    name: "gchat",
    type: "awaitedCommand",
    code: `
    $channelSendMessage[$getServerVar[gchatch];{author:$userTag[$authorID] ($authorID):$authorAvatar} {description:${msg}} {color:RANDOM} {footer:jakis footer XD}]
$cooldown[2s]
$suppressErrors[]`
}]